#!/bin/sh

tonodes -r /opt/qt/ l-crwl[2-7,9,10]:/opt/qt -rsync -archive -update -compress
