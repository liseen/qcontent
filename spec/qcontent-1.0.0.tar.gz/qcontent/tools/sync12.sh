#!/usr/bin/env bash

BIN=$(readlink -f -- $(dirname -- "$0"))
cd $BIN/..

test -f Makefile && make distclean

rsync --exclude 'pipeline/*' --exclude '*~' --exclude '*.t' --exclude '*.vdom' -auvz * xunxin.wan@crwl12:/home/xunxin.wan/qcontent/
