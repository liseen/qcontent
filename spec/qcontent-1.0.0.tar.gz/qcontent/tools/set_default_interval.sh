#!/bin/bash

echo -e "set_default_interval\t$1" |  uqmgr -h l-crwl2
