#!/bin/sh

atnodes 'tail /export/m4/qextractor-log/qextractor.INFO' -L l-crwl[2-7]
