#!/bin/sh

exec qurluniqmgr set "l-crwl1:9851,l-crwl1:9852,l-crwl1:9853,l-crwl1:9854,l-crwl2:9851,l-crwl2:9852,l-crwl2:9853,l-crwl2:9854,l-crwl3:9851,l-crwl3:9852,l-crwl3:9853,l-crwl3:9854,l-crwl4:9851,l-crwl4:9852,l-crwl4:9853,l-crwl4:9854,l-crwl5:9851,l-crwl5:9852,l-crwl5:9853,l-crwl5:9854,l-crwl6:9851,l-crwl6:9852,l-crwl6:9853,l-crwl6:9854"
