/*
 * Copyright 2011 Qunar Inc.
 * BSD license
 * Author
 *    xunxin.wan (万珣新) <xunxin.wan@qunar.com>
 */

#include "qpredict_document.h"

namespace qcontent
{

QPredictDocument::QPredictDocument()
{
}

QPredictDocument::~QPredictDocument()
{
}

/*
bool parse_term_from_line(const std::string &line)
{

    return 0;
}

bool parse_feature_from_line(const std::string &line)
{

    return 0;
}
*/
} // end for namespace qcontent

