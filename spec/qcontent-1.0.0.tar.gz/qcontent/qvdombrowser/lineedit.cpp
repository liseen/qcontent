#include "lineedit.h"
#include "qevent.h"

/*
void LineEdit::focusInEvent(QFocusEvent* e) {
    //QLineEdit::focusInEvent(e);
    //setFocus();
    selectAll();
    //fprintf(stderr, "focusing lineEdit...\n");
    e->ignore();
    update();
}
*/

