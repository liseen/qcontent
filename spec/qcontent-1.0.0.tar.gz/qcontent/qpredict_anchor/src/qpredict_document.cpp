#include <vector>

#include "qpredict_document.h"

using namespace std;

namespace qcontent {

// add the url's term in to terms

void QPredictDocument::add_term(const string &t) {
    if(t.empty()) {
        return;
    }
    
    TermHashIter it = terms.find(t);
    if (it == terms.end()) {
        QPredictTerm term;
        term.tf = 1;
        terms[t] = term;
    } else {
        ++(it->second.tf);
    }
}

}
