/*
 * Copyright 2011 Qunar Inc.
 * BSD license
 * Author
 *    zhenbao.zhou
 */
#include <vector>
#include <string>

#include "url_dealer.h"

#include "strtk.hpp"
#include "googleurl/src/gurl.h"
#include "qpredict_document.h"

#define TERM_MAX_SIZE 20
namespace qcontent {
    //  split the url. store terms into term_vector
bool QUrlDealer::extract_term(const std::string &url,
                              std::vector<std::string> &term_vector) {
    GURL gurl(url);
    const std::string &host = gurl.host();
    if (host.empty()) {
        return false;
    }

    term_vector.push_back(host);

    const std::string &path = gurl.path();
    const std::string &query = gurl.query();

    std::vector<std::string> path_vector;
    strtk::parse(path, "/_-", path_vector);
    for (unsigned int i = 0; i < path_vector.size(); i++) {
        std::string &path_seg = path_vector[i];

         if (path_seg.size() < TERM_MAX_SIZE) {
             // discard string the length of which is too long
             // eg %E8%AF%B8%E5%9F%8E%E5%BE%97%E5%88%A9%
             term_vector.push_back(path_seg);
         }
    }

    std::vector<std::string> query_vector;
    strtk::parse(query, "&", query_vector);
    for (unsigned int i = 0; i < query_vector.size(); i++) {
        const std::string &tmp = query_vector[i];
        if (!tmp.empty()) {
            std::vector<std::string> key_value;
            if (tmp.size() < TERM_MAX_SIZE) {
                term_vector.push_back(tmp);
            }

                // 参数也要使用
            strtk::parse(tmp, "=", key_value);
            if (key_value.size() == 1 || key_value.size() == 2) {
                const std::string &key = key_value[0];
                if (key.size() < TERM_MAX_SIZE) {
                    term_vector.push_back(key);
                }
            }
        }
    }

    return true;
}

int QUrlDealer::guess_url_type(const std::string &url) {
    return 0;
}

}
