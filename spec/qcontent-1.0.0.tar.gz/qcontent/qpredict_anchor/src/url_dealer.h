/*
 * Copyright 2011 Qunar Inc.
 * BSD license
 * Author
 *    zhenbao.zhou
 */


#ifndef QPREDICT_ANCHOR_SRC_URL_DEALER_H_
#define QPREDICT_ANCHOR_SRC_URL_DEALER_H_

#include <vector>
#include <string>

#include "strtk.hpp"
#include "googleurl/src/gurl.h"

namespace qcontent {

class QUrlDealer {
  public:
    QUrlDealer() {}
    virtual ~QUrlDealer() {}

    bool extract_term(const std::string &url,
                      std::vector<std::string> &term_vector);

  private:
    int guess_url_type(const std::string &url);
};
}
#endif  // QPREDICT_ANCHOR_SRC_URL_DEALER_H_

