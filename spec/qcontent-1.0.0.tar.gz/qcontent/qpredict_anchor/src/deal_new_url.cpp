/*
 * Copyright 2011 Qunar Inc.
 * BSD license
 * Author
 *    xunxin.wan (万珣新) <xunxin.wan@qunar.com>
 */

/*
 * qpedict tool for train and predict
 *
 */
#include <getopt.h>
#include <strtk.hpp>
#include <string>
#include <vector>
#include "qcontent_config.h"
#include "qpredict_log.h"
#include "qpredict.h"

static void print_usage(FILE* stream, int exit_code) {
    fprintf(stream, "Usage: qpredict options \n");
    fprintf(stream,
            "  -h --help               Display this usage information.\n"
            "  -c --conf <file>        Config file\n");

    exit(exit_code);
}


int main(int argc, char *argv[]) {
    std::string config_file = "./qpredict.conf";

    const char* const short_options = "htvc:";
    const struct option long_options[] = {
        { "help",     0, NULL, 'h' },
        { "conf",    1, NULL, 'c' },
        { NULL,       0, NULL, 0   }
    };

    int next_option;
    do {
        next_option = getopt_long(argc, argv, short_options,
                               long_options, NULL);
        switch (next_option) {
            case 'h':
                print_usage(stdout, 0);
                break;
            case 'c':
                config_file = optarg;
                break;
            case -1:
                break;
            case '?':
                print_usage(stderr, 1);
            default:
                print_usage(stderr, 1);
        }
    } while (next_option != -1);

    qcontent::QPredict qpredict;

    qcontent::QContentConfig *qcontent_config =
            qcontent::QContentConfig::get_instance();
    if (!qcontent_config->parse_file(config_file)) {
        LOG(FATAL) << "parse config file error";
        exit(-1);
    }

    qcontent::QPredictConfig config(qcontent_config->values_map());

    bool init_ret = qpredict.init(&config);
    if (!init_ret) {
        LOG(FATAL) << "init qpredict fatal";
    }

    bool load_ret = qpredict.load_qpredict_model();
    if (!load_ret) {
        LOG(FATAL) << "load fatal";
    }

    int lineno = 0;
    std::string line;
    std::vector<std::string> results;
    int label_id = -1;

    while (std::getline(std::cin, line)) {
        ++lineno;
        if (line.empty()) {
            LOG(WARNING) << "empty line no: " << lineno;
            continue;
        }

        results.clear();
        qcontent::QPredictDocument doc;
        bool valid = strtk::parse(line, "\t", results);

        if (!valid) {
            continue;
        }
        if (results.size() != 11) {
//            LOG(WARNING) << "invalid line : " << line;
            std::cout << line << "\t" << "-1" << std::endl;
            continue;
        }

        if (results[1].empty()) {
            LOG(WARNING) << "Empty url. invalid line " << line;
            continue;
        }

        if (results[2].empty()) {
            LOG(WARNING) << "Empty anchor. predict value : -1";
            std::cout << line << "\t" << "-1" << std::endl;
            continue;
        }

        doc.url = results[1];
        doc.raw_data = results[2];

        bool predict_ret = qpredict.predict(doc);
        if (!predict_ret) {
            LOG(WARNING) << "predict line no: " << lineno << "fail";
            continue;
        }

        if (label_id == -1) {
            for (size_t i = 0; i < qpredict.class_id2label.size(); i++) {
                if (qpredict.class_id2label[doc.predict_class_labels[i]] == "trip") {
                    label_id = i;
                    break;
                }
            }
        }

        if (label_id != -1) {
            int anchor_predict = int(100 * doc.predict_class_probs[label_id]);
            std::cout<< line << "\t" << anchor_predict << std::endl;
        }
    }

    return 0;
}
