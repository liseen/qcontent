/*
 * Copyright 2011 Qunar Inc.
 * BSD license
 * Author
 *    xunxin.wan (万珣新) <xunxin.wan@qunar.com>
 *
 * qpredict_log.h
 *
 */

#ifndef QPREDICT_LOG
#define QPREDICT_LOG

#include <glog/logging.h>

#endif

