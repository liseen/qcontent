/*
 * Copyright 2011 Qunar Inc.
 * BSD license
 * Author
 *    xunxin.wan (万珣新) <xunxin.wan@qunar.com>
 */

#include <cstdio>
#include <jpeglib.h>
#include <jerror.h>

#define cimg_display 0

#define cimg_plugin "plugins/jpeg_buffer.h"

#include "CImg.h"
#include <string>
#include <iostream>
#include <cassert>

#include <getopt.h>
#include <tcrdb.h>
#include <strtk.hpp>

#include <QBuffer>
#include <QImage>
#include <QCryptographicHash>

std::string base64_encode(unsigned char const* , unsigned int len);
std::string base64_decode(std::string const& s);

#define QBUF_SIZE 50000

using namespace cimg_library;

static int scaled_h = 80;
static int scaled_w = 120;

static JOCTET joctet_buf[QBUF_SIZE];

std::string corp_and_encode_image(unsigned char *raw_data, size_t raw_data_size) {

    QImage qimg = QImage::fromData((const uchar*)raw_data, raw_data_size);

    if (qimg.isNull() || qimg.width() <= 0) {
        return "";
    }

    QByteArray ba;
    QBuffer buffer(&ba);
    buffer.open(QIODevice::WriteOnly);
    qimg.save(&buffer, "jpeg");

    CImg<unsigned char> img;
    img.load_jpeg_buffer((JOCTET*)ba.data(), ba.size());

    //img.load_jpeg_buffer((JOCTET*)raw_data, raw_data_size);
    //std::cerr << "debug" << std::endl;
    if (img.width() == 0 || img.height() == 0) {
        return "";
    }

    double w_ratio =  static_cast<double>(scaled_w) / img.width();
    double h_ratio =  static_cast<double>(scaled_h) / img.height();
    //double ratio;
    if (w_ratio < h_ratio) {
        int resize_w = img.width() * h_ratio;
        img.resize(resize_w, scaled_h);
        int x0 = (resize_w - scaled_w)/2;
        img.crop(x0, 0, scaled_w + x0 - 1, scaled_h - 1);
    } else {
        int resize_h = img.height() * w_ratio;
        img.resize(scaled_w, resize_h);
        int y0 = (resize_h - scaled_h)/2;
        img.crop(0, y0, scaled_w - 1, scaled_h + y0 - 1, false);
    }

    JOCTET *buffer_output = joctet_buf;
    unsigned int data_size = 0;
    img.save_jpeg_buffer(buffer_output, data_size, 100);

    std::string base64("data:image/jpeg;base64,");
    base64.append(base64_encode((unsigned char*) buffer_output, data_size));

    return base64;
}

static std::string md5_hash(const std::string &data)
{
    return std::string(QCryptographicHash::hash(QByteArray(data.c_str(), \
                    data.size()), QCryptographicHash::Md5).toHex().constData());
}

static void print_usage(FILE* stream, int exit_code) {
    fprintf(stream, "Usage: qimgcrop options \n");
    fprintf(stream,
            "  -h --host <host>  Host.\n"
            "  -p --port <port>  Port.\n");

    exit(exit_code);
}


int main(int argc, char *argv[]) {

    std::string media_host = "crwl5";
    uint16_t media_port = 9880;

    const char* const short_options = "h:p:";
    const struct option long_options[] = {
        { "host",  1, NULL, 'h' },
        { "port",  1, NULL, 'p' },
        { NULL,    0, NULL, 0   }
    };

    int next_option;
    do {
        next_option = getopt_long (argc, argv, short_options,
                               long_options, NULL);
        switch (next_option) {
            case 'h':
                media_host = optarg;
                break;
            case 'p':
                media_port = (uint16_t)atoi(optarg);
                break;
            case -1:
                break;
            case '?':
                print_usage(stderr, 1);
            default:
                print_usage(stderr, 1);
        }
    } while (next_option != -1);

    TCRDB *rdb;
    int ecode;
    char *value;

    rdb = tcrdbnew();
    /* connect to the server */
    if(!tcrdbopen(rdb, media_host.c_str(), media_port)){
        ecode = tcrdbecode(rdb);
        fprintf(stderr, "open media db error: %s\n", tcrdberrmsg(ecode));
        print_usage(stderr, 2);
    }

    std::string line;
    while (getline(std::cin, line)) {
        if (line.empty()) {
            continue;
        }

        std::vector<std::string> splits;
        strtk::parse(line.c_str(), line.c_str() + line.size(),  "\t", splits, strtk::split_options::default_mode);
        if (splits.size() < 3) {
            continue;
        }

        std::string md5 = splits[0];
        std::string url = splits[1];
        std::string raw_url = splits[2];

        std::string key = md5_hash(raw_url) + ".i";

        int img_raw_content_size = 0;
        value = (char*)tcrdbget(rdb, key.c_str(), key.size(), &img_raw_content_size);
        if (value) {
            // for performance
            if (img_raw_content_size >= 20) {
                std::string base64 = corp_and_encode_image((unsigned char*)value, img_raw_content_size);
                if (!base64.empty()) {
                    std::cout << line << "\t" << base64 << "\n";
                }
            }
            free(value);
        } else {
            ecode = tcrdbecode(rdb);
            if (ecode == 7) {
                fprintf(stderr, "NA\t%s\n", line.c_str());
            } else {
                fprintf(stderr, "get error: %s, data: %s\n", tcrdberrmsg(ecode), line.c_str());
            }
        }
    }

    /* close the connection */
    if(!tcrdbclose(rdb)){
        ecode = tcrdbecode(rdb);
        fprintf(stderr, "close error: %s\n", tcrdberrmsg(ecode));
    }

    /* delete the object */
    tcrdbdel(rdb);


};

/*
   base64.cpp and base64.h

   Copyright (C) 2004-2008 René Nyffenegger

   This source code is provided 'as-is', without any express or implied
   warranty. In no event will the author be held liable for any damages
   arising from the use of this software.

   Permission is granted to anyone to use this software for any purpose,
   including commercial applications, and to alter it and redistribute it
   freely, subject to the following restrictions:

   1. The origin of this source code must not be misrepresented; you must not
      claim that you wrote the original source code. If you use this source code
      in a product, an acknowledgment in the product documentation would be
      appreciated but is not required.

   2. Altered source versions must be plainly marked as such, and must not be
      misrepresented as being the original source code.

   3. This notice may not be removed or altered from any source distribution.

   René Nyffenegger rene.nyffenegger@adp-gmbh.ch

*/


static const std::string base64_chars = 
             "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
             "abcdefghijklmnopqrstuvwxyz"
             "0123456789+/";


static inline bool is_base64(unsigned char c) {
  return (isalnum(c) || (c == '+') || (c == '/'));
}

std::string base64_encode(unsigned char const* bytes_to_encode, unsigned int in_len) {
  std::string ret;
  int i = 0;
  int j = 0;
  unsigned char char_array_3[3];
  unsigned char char_array_4[4];

  while (in_len--) {
    char_array_3[i++] = *(bytes_to_encode++);
    if (i == 3) {
      char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
      char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
      char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
      char_array_4[3] = char_array_3[2] & 0x3f;

      for(i = 0; (i <4) ; i++)
        ret += base64_chars[char_array_4[i]];
      i = 0;
    }
  }

  if (i)
  {
    for(j = i; j < 3; j++)
      char_array_3[j] = '\0';

    char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
    char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
    char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
    char_array_4[3] = char_array_3[2] & 0x3f;

    for (j = 0; (j < i + 1); j++)
      ret += base64_chars[char_array_4[j]];

    while((i++ < 3))
      ret += '=';

  }

  return ret;

}

std::string base64_decode(std::string const& encoded_string) {
  int in_len = encoded_string.size();
  int i = 0;
  int j = 0;
  int in_ = 0;
  unsigned char char_array_4[4], char_array_3[3];
  std::string ret;

  while (in_len-- && ( encoded_string[in_] != '=') && is_base64(encoded_string[in_])) {
    char_array_4[i++] = encoded_string[in_]; in_++;
    if (i ==4) {
      for (i = 0; i <4; i++)
        char_array_4[i] = base64_chars.find(char_array_4[i]);

      char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
      char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
      char_array_3[2] = ((char_array_4[2] & 0x3) << 6) + char_array_4[3];

      for (i = 0; (i < 3); i++)
        ret += char_array_3[i];
      i = 0;
    }
  }

  if (i) {
    for (j = i; j <4; j++)
      char_array_4[j] = 0;

    for (j = 0; j <4; j++)
      char_array_4[j] = base64_chars.find(char_array_4[j]);

    char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
    char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
    char_array_3[2] = ((char_array_4[2] & 0x3) << 6) + char_array_4[3];

    for (j = 0; (j < i - 1); j++) ret += char_array_3[j];
  }

  return ret;
}

