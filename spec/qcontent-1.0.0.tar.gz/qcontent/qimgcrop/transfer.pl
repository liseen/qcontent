#!/usr/bin/env perl

use strict;
use warnings;
#use Smart::Comments;

use Getopt::Long;
use TokyoTyrant;
use Digest::MD5 qw(md5 md5_hex);

my $old_host = "l-crwl4";
my $old_port = 9860;

my $new_host = "l-crwl5";
my $new_port = 9880;

my $old_rdb = TokyoTyrant::RDB->new();

# connect to the server
if(!$old_rdb->open($old_host, $old_port)){
    my $ecode = $old_rdb->ecode();
    printf STDERR ("open old db error: %s\n", $old_rdb->errmsg($ecode));
}

my $new_rdb = TokyoTyrant::RDB->new();

# connect to the server
if(!$new_rdb->open($new_host, $new_port)){
    my $ecode = $new_rdb->ecode();
    printf STDERR ("open new db error: %s\n", $new_rdb->errmsg($ecode));
}

my $lineno = 0;
while (<>) {
    chomp;
    ++$lineno;
    if ($lineno % 10000 == 0) {
        warn "$lineno!\n";
    }

    my $line = $_;
    my ($md5, $url, $raw_url) = split /\t/, $line;
    next if !$raw_url;

    my $key = md5_hex($raw_url) . ".i";

    if ($lineno >= 30000) {
        my $image = $old_rdb->get($key);
        if ($image && length($image) > 10) {
            if (!$new_rdb->put($key, $image)) {
                my $ecode = $new_rdb->ecode();
                printf STDERR ("put new db error: %s\n", $new_rdb->errmsg($ecode));
            }
        }
    }
    print $line . "\n";
}

# close the connection
if( !$old_rdb->close() ) {
    my $ecode = $old_rdb->ecode();
    printf STDERR ("close error: %s\n", $old_rdb->errmsg($ecode));
}

# close the connection
if( !$new_rdb->close() ) {
    my $ecode = $new_rdb->ecode();
    printf STDERR ("close error: %s\n", $new_rdb->errmsg($ecode));
}
