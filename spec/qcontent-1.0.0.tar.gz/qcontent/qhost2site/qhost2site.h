/*
 * Copyright 2011 Qunar Inc.
 * BSD license
 * Author
 *    xunxin.wan (万珣新) <xunxin.wan@qunar.com>
 */

#ifndef QHOST_TO_SITE_H_
#define QHOST_TO_SITE_H_

std::string qhost2site(const std::string &host);

#endif
