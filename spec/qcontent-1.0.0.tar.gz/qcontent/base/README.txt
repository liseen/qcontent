These files contain some shared code. You can define your own assertion macros
to eliminate the dependency on logging.h.
