#ifndef DDEBUG_H
#define DDEBUG_H

#include <iostream>


#define DD(x) std::cout << x << std::endl;

#endif

