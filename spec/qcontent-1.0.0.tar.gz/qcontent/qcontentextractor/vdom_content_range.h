/*
 *
 *
 */

#ifndef VDOM_CONTENT_RANGE_H

#include <string>

namespace vdom {
namespace content {

struct BlockRange {

}

} //namespace vdom
} //namespace content

#endif
